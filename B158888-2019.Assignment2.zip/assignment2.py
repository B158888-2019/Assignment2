#!/bin/python3
import subprocess as sp
import os,sys
import pandas as pd
#set a loop list for the confirm process afterwards
loop1=["1"]
for n1 in loop1:
  #interact with user
  #determine the protein family and the taxonomic group
  proname=input('Please enter the protein name:\n')
  taxo=input('Please enter the taxonomy:\n')
  #save variables into a file
  q=open("queryfile","w")
  q.write(proname)
  q.write(" ")
  q.write(taxo)
  q.write('\n')
  q.close()
  #obtain the relevant sequence data
  print('Searching sequences for you now...')
  sp.call('while read name tax; do esearch -db protein -query "$name[Protein Name] AND $tax[Organism]" | efetch -format fasta > pro_seq; done < queryfile',shell=True)
  #calculate how many sequences we got
  seqs=open("pro_seq").read()
  count=0
  for line in seqs:
    if line.startswith(">"):
      count+=1
  #give the user options to contine or not with current dataset
  print("There are ",count,"sequences for ",proname,taxo)
  #set a loop for the confirmation steps, in case the user entered something stupid
  loop2=["1"]
  for n2 in loop2:
    confirm=input("Do you want to continue with this dataset?(y/n)\n")
    if confirm.lower() == "y":
      print('Requests confirmed. Continuing...')
      continue
    elif confirm.lower() == "n":
      print('OK. Lets change our requests.')
      loop1.append("1")
      break
    else:
      print("Characters cant be recognised. Please enter y or n.")
      loop2.append("1")
os.remove("queryfile")
#limit the number of sequences used for conservation analysis
if count>250:
  print('Oh there are too many sequences! We will only take the best 250 for the rest of things.')
  print('This will take much of time. Please wait for a moment...')
  #run blastp to get the similarity between each sequences
  sp.call('makeblastdb -in pro_seq -dbtype prot -out pro_db',shell=True)
  sp.call('blastp -db pro_db -query pro_seq -outfmt 6 > blastout',shell=True)
  #get the average of bit-scores of each protein. The higher the sum is, indicating the more similar the sequence is against the others
  blout=open('blastout').read().rstrip()
  query_seq=""
  score=0
  hits=0
  bs={}
  for line in blout.split('\n'):
    if line.split()[0]!=query_seq:
      if query_seq!="":
        bs[query_seq]=score/hits
        score=0
        hits=0
      query_seq=line.split()[0]
    else:
      score+=float(line.split()[11])
      bs[query_seq]=score
      hits+=1
  bs[query_seq]=score/hits
  #sort it in decreasing numeric value
  sort_bs=sorted(bs.items(),key=lambda x: x[1],reverse=True)
  #get the uids for the first 250 sequences
  count=0
  for i in sort_bs:
    if count < 250:
      q=open("uids","a")
      q.write(list(i)[0])
      q.write('\n')
      q.close()
      count+=1
    else:
      break
  #search and fetch the sequences of the first 250 proteins
  os.remove("pro_seq")
  sp.call('rm pro_db*',shell=True)
  os.remove("blastout")
  sp.call('for uid in $(cat uids); do esearch -db protein -query "$uid" | efetch -format fasta >> pro_seq; done',shell=True)
  os.remove("uids")
#align the sequences with clustalo
print('Aligning sequences...')
sp.call('clustalo -i pro_seq -o aligned_seq',shell=True)
#calculate the counts of gaps in each sequences
aligned=open('aligned_seq').read().rstrip()
g=0
gap={}
for line in aligned.split('\n'):
  if line.startswith('>'):
    uid=line.split(' ')[0]
    g=0
  else:
    g+=line.count('-')
    gap[uid]=g
#get the sequence with the least gaps as our query sequence
sort_gap=sorted(gap.items(),key=lambda x: x[1])
seq=list(sort_gap[0])[0].strip(">")
qr=open('query','w')
qr.write(seq)
qr.write('\n')
qr.close()
sp.call('while read uid; do esearch -db protein -query "$uid" | efetch -format fasta > query_seq; done < query',shell=True)
os.remove("query")
#run blastp to get the similarity between each sequences
print('Now building your blastp database...')
sp.call('makeblastdb -in pro_seq -dbtype prot -out pro_db',shell=True)
print('Blasting...')
sp.call('blastp -db pro_db -query query_seq -outfmt 6 > blastout',shell=True)
print('The blast output has been saved in a file named as "blastout".')
#build a dataframe using pandas
blastoutput=pd.read_csv('blastout',sep='\t',header=None)
headings=['query_seq','subject_seq','identity','length','mismatch','gap','q.start','q.end','s.start','s.end','e.value','bit.score']
blastoutput.columns=headings
#plot the average similarity among the sequences in this protein family as the level of conservation
aver=blastoutput['identity'].mean()
print('The average identity among sequences in this protein family is:',aver)
con=open('conservation','w')
con.write('The average identity among sequences in this protein family is:')
con.write(str(aver))
con.close()
print('This output has been saved in a file named "conservation".')
#use plotcon to plot conservation of a sequence alignment
print('Ploting the conservation graph for you...')
print('PLease mind: this graph will NOT saved in any files!')
sp.call('plotcon aligned_seq ',shell=True)
#use EMBOSS patmatmotifs to scan the query_seq with motifs from PROSITE database
print('Scanning motifs...')
sp.call('patmatmotifs query_seq motifs',shell=True)
print('The output has been saved in a file called "motifs".')
os.remove("aligned_seq")
#wildcard: predict secondary structure of the query_seq
print('Predicting secondary structure...')
sp.call('garnier query_seq structure',shell=True)
print('The output has been saved in a file called "structure".')

